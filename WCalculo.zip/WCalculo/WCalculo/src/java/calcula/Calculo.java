package calcula;

public class Calculo {

    private double salarioBruto;

    public Calculo() {

    }

    public Calculo(double sb) {
        this.setSalarioBruto(sb);
    }

    public double getSalarioBruto() {
        return salarioBruto;
    }

    public void setSalarioBruto(double salarioBruto) {
        this.salarioBruto = salarioBruto;
    }

    public double caculaFGTS(double fgts) {
        fgts = salarioBruto * 0.8;
        return fgts;
    }
    
    private double calculaINSS(double inss) {
        if (salarioBruto == 1045.00) {
            inss = salarioBruto * 0.075;
        } else if (salarioBruto >= 1045.01 && salarioBruto <= 2089.60) {
            inss = salarioBruto * 0.9;
        } else if (salarioBruto >= 2089.61 && salarioBruto <= 3134.40) {
            inss = salarioBruto * 0.12;
        } else if (salarioBruto >= 3134.41 && salarioBruto <= 6101.06) {
            inss = salarioBruto * 0.14;
        } else{
            System.out.println("Valor inválido.");
        }
        
        return inss;
    }
    
    public double calculaIR(double ir) {
        if (salarioBruto == 1045.00) {
            ir = 
        } else if (salarioBruto >= 1045.01 && salarioBruto <= 2089.60) {
            ir = 
        } else if (salarioBruto >= 2089.61 && salarioBruto <= 3134.40) {
            ir = 
        } else if (salarioBruto >= 3134.41 && salarioBruto <= 6101.06) {
            ir = 
        } else{
            System.out.println("Valor inválido.");
        }
        
        return ir;
    }
}
